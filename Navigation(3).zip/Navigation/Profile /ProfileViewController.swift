//
//  ProfileViewController.swift
//  Navigation
//
//  Created by Захар Кисляк on 23.10.2022.
//

import UIKit

final class ProfileViewController: UIViewController {
    
    //MARK: Свойства
    
   let profileHeaderView = ProfileHeaderView()
    
    
    
    // MARK: Добавление кнопки
    
    private let buttonShowStatus: UIButton = {
        
        let button = UIButton(frame: CGRect(x: 200, y: 200, width: 50, height: 50))
        button.setTitle("Show status", for: .normal)
        button.titleLabel?.textColor = .white
        button.backgroundColor = .blue
        button.layer.cornerRadius = 4 
        return button
    }()
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.addSubview(profileHeaderView)
        self.title = "Profile"
        buttonShowStatus.addSubview(buttonShowStatus)
        self.navigationController?.navigationBar.backgroundColor = .white
       
    }
    
 
    
    override func viewDidLayoutSubviews() {
        profileHeaderView.frame = view.frame
    }
}
