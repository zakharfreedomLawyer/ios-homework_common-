//
//  ViewController.swift
//  Navigation
//
//  Created by Захар Кисляк on 22.10.2022.
//

import UIKit

final class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .orange
        

    }


}

