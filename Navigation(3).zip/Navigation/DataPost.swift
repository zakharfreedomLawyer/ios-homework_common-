//
//  DataPost.swift
//  Navigation
//
//  Created by Захар Кисляк on 23.10.2022.
//

import UIKit 

struct Post {
    var title:String
    var description:String
}

